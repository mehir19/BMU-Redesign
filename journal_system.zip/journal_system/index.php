<?php
include 'db.php';

// Route active view targets
$view = $_GET['view'] ?? 'home';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Academic Research Journal Portal</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background-color: #f4f6f9; color: #333; line-height: 1.6; }
        
        /* Navigation Bar */
        header { background: #1a252f; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; color: #fff; }
        header .logo { font-size: 22px; font-weight: bold; letter-spacing: 1px; }
        nav a { color: #cbd5e1; text-decoration: none; margin-left: 20px; font-size: 15px; transition: color 0.2s; }
        nav a:hover, nav a.active { color: #3498db; }

        /* Layout Architecture */
        .wrapper { display: flex; max-width: 1300px; margin: 30px auto; padding: 0 20px; gap: 30px; }
        .main-content { flex: 7; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .sidebar-panel { flex: 3; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); height: fit-content; }

        /* Typography & Components */
        h2 { margin-bottom: 20px; color: #2c3e50; border-bottom: 2px solid #ecf0f1; padding-bottom: 8px; }
        .article-card { background: #fafbfc; border: 1px solid #e2e8f0; padding: 20px; margin-bottom: 20px; border-radius: 6px; }
        .article-card h3 { color: #2980b9; margin-bottom: 10px; }
        .meta-tag { display: inline-block; background: #e8f4fd; color: #2b6cb0; font-size: 12px; padding: 3px 8px; border-radius: 4px; margin-bottom: 10px; font-weight: 600; }
        
        /* Unified Form Styling */
        .login-form label { display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px; color: #4a5568; }
        .login-form select, .login-form input { width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #cbd5e1; border-radius: 4px; font-size: 14px; }
        .login-form button { width: 100%; background: #3498db; color: white; border: none; padding: 12px; border-radius: 4px; font-weight: bold; cursor: pointer; font-size: 15px; transition: background 0.2s; }
        .login-form button:hover { background: #2980b9; }
        .error-msg { color: #e53e3e; background: #fff5f5; padding: 10px; border-left: 4px solid #e53e3e; margin-bottom: 15px; font-size: 14px; }
    </style>
</head>
<body>

    <header>
        <div class="logo">ScholarJournal</div>
        <nav>
            <a href="index.php?view=home" class="<?= $view == 'home' ? 'active' : '' ?>">Home / Articles</a>
            <a href="index.php?view=about" class="<?= $view == 'about' ? 'active' : '' ?>">About Us</a>
            <a href="index.php?view=contact" class="<?= $view == 'contact' ? 'active' : '' ?>">Contact</a>
        </nav>
    </header>

    <div class="wrapper">
        
        <main class="main-content">
            <?php if ($view == 'about'): ?>
                <h2>About Our Journal</h2>
                <p>Welcome to ScholarJournal, a peer-reviewed open-access platform dedicated to publishing high-quality academic research papers across engineering, medical breakthroughs, and data science disciplines.</p>
                <p style="margin-top:15px;">Our automated workflow ensures structural peer evaluations, strict formatting benchmarks, and global digital distribution once published.</p>

            <?php elseif ($view == 'contact'): ?>
                <h2>Contact Editorial Office</h2>
                <p>Have inquiries regarding your manuscript submission or guidelines? Reach out directly to our processing management desk:</p>
                <p style="margin-top: 15px;"><strong>Email:</strong> support@scholarjournal.org<br>
                   <strong>Office Hours:</strong> Sunday – Thursday, 09:00 AM - 05:00 PM</p>

            <?php else: ?>
                <h2>Published Research Repository</h2>
                <?php
                // Fetch all published articles from database
                $query = "SELECT a.title, a.abstract, a.formatted_file_path, a.created_at, u.username AS author 
                          FROM articles a 
                          JOIN users u ON a.author_id = u.id 
                          WHERE a.status = 'Published' 
                          ORDER BY a.id DESC";
                $published = $conn->query($query);

                if ($published && $published->num_rows > 0):
                    while($row = $published->fetch_assoc()):
                ?>
                        <div class="article-card">
                            <h3><?= htmlspecialchars($row['title']) ?></h3>
                            <span class="meta-tag">Published: <?= date('M d, Y', strtotime($row['created_at'])) ?></span>
                            <p style="font-size:14px; margin-bottom: 12px; color:#4a5568;"><strong>Author:</strong> <?= htmlspecialchars($row['author']) ?></p>
                            <p style="color: #4a5568; margin-bottom: 15px;"><?= htmlspecialchars($row['abstract']) ?></p>
                            <a href="<?= htmlspecialchars($row['formatted_file_path']) ?>" download style="color:#3498db; font-weight:600; text-decoration:none; font-size:14px;">Download Full Manuscript (PDF) &rarr;</a>
                        </div>
                <?php 
                    endwhile; 
                else: 
                ?>
                    <p style="color: #718096;">No articles have been officially published in this issue yet.</p>
                <?php endif; ?>
            <?php endif; ?>

            <?php
            // Replace the internal dynamic code block inside index.php under the primary canvas else check conditions:
            if ($view == 'home' || $view == 'home'):
                $current_year = date('Y');
            ?>
                <h2>Current Issue (Volume <?= $current_year ?>)</h2>
                <?php
                // Fetch articles from the current calendar year
                $current_query = "SELECT a.*, u.username FROM articles a JOIN users u ON a.author_id = u.id 
                                WHERE a.status = 'Published' AND YEAR(a.created_at) = '$current_year' ORDER BY a.id DESC";
                $current_issue = $conn->query($current_query);
                
                if ($current_issue && $current_issue->num_rows > 0):
                    while($row = $current_issue->fetch_assoc()): ?>
                        <div class="article-card">
                            <h3><?= htmlspecialchars($row['title']) ?></h3>
                            <p style="font-size:13px; color:#718096;">Author: <?= htmlspecialchars($row['username']) ?></p>
                            <p><?= htmlspecialchars($row['abstract']) ?></p>
                            <a href="<?= htmlspecialchars($row['formatted_file_path']) ?>" download style="color:#3498db; font-weight:600;">Download Full PDF</a>
                        </div>
                <?php endwhile; else: echo "<p>No entries found in the current year's issue volume layout.</p>"; endif; ?>

                <br><br>
                <h2>Journal Archives (Past Volumes)</h2>
                <?php
                // Pull entries from previous calendar years
                $archive_query = "SELECT a.*, u.username FROM articles a JOIN users u ON a.author_id = u.id 
                                WHERE a.status = 'Published' AND YEAR(a.created_at) < '$current_year' ORDER BY a.created_at DESC";
                $archives = $conn->query($archive_query);

                if ($archives && $archives->num_rows > 0):
                    $last_year = "";
                    while($row = $archives->fetch_assoc()):
                        $pub_year = date('Y', strtotime($row['created_at']));
                        if ($pub_year !== $last_year) {
                            echo "<h3 style='margin:20px 0 10px 0; color:#2c3e50; background:#edf2f7; padding:5px 10px;'>Year: $pub_year</h3>";
                            $last_year = $pub_year;
                        }
                ?>
                        <div class="article-card" style="margin-left: 15px;">
                            <h4><?= htmlspecialchars($row['title']) ?></h4>
                            <p style="font-size:12px; color:#718096;">By: <?= htmlspecialchars($row['username']) ?></p>
                            <a href="<?= htmlspecialchars($row['formatted_file_path']) ?>" download style="color:#4a5568; font-size:13px;">View Archived PDF</a>
                        </div>
                <?php endwhile; else: echo "<p style='color:#a0aec0;'>Archived timeline records are currently empty.</p>"; endif; ?>

            <?php endif; ?>
        </main>

        <aside class="sidebar-panel">
            <h3>Portal Access Dashboard</h3>
            <p style="font-size: 13px; color: #718096; margin-bottom: 20px;">Select your assigned system identity profile below to verify credentials and manage articles.</p>
            
            <?php 
            // Display errors if redirected from failed submission handling
            if (isset($_GET['login_error'])) {
                echo '<div class="error-msg">' . htmlspecialchars($_GET['login_error']) . '</div>';
            }
            ?>

            <form action="process_login.php" method="POST" class="login-form">
                <label for="user_select">Select Registered Profile</label>
                <select name="user_id" id="user_select" required>
                    <option value="" disabled selected>-- Select Your Identity --</option>
                    <?php
                    // Dynamically populate user array categories directly from database configuration
                    $user_query = $conn->query("SELECT id, username, role FROM users ORDER BY role ASC, username ASC");
                    if($user_query) {
                        while($user = $user_query->fetch_assoc()) {
                            echo "<option value='{$user['id']}'>{$user['username']} ({$user['role']})</option>";
                        }
                    }
                    ?>
                </select>

                <label for="password_field">Secure Password</label>
                <input type="password" name="password" id="password_field" required placeholder="••••••••">

                <button type="submit">Authenticate Session</button>
            </form>
        </aside>

    </div>

</body>
</html>