<?php
include 'db.php';

// Route Guard: Access allowed only for logged-in Reviewers
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Reviewer') {
    header("Location: index.php?login_error=Unauthorized access restricted to Reviewers.");
    exit();
}

$reviewer_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reviewer Portal Hub</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: sans-serif; }
        body { display: flex; background: #f4f6f9; color: #333; }
        .sidebar { width: 250px; background: #2c3e50; color: white; height: 100vh; padding: 20px; position: fixed; }
        .sidebar h3 { margin-bottom: 5px; color: #fff; }
        .sidebar p { font-size: 13px; color: #bdc3c7; margin-bottom: 20px; }
        .sidebar a { color: #ecf0f1; display: block; padding: 12px; text-decoration: none; border-radius: 4px; margin-bottom: 5px; }
        .sidebar a:hover { background: #34495e; }
        .main-content { margin-left: 250px; flex: 1; padding: 40px; }
        h2 { border-bottom: 2px solid #ddd; padding-bottom: 10px; margin-bottom: 20px; color: #2c3e50; }
        .article-box { background: #fff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .article-box h4 { color: #2980b9; margin-bottom: 8px; }
        textarea { width: 100%; height: 100px; padding: 10px; margin: 10px 0; border: 1px solid #cbd5e1; border-radius: 4px; resize: vertical; }
        button { background: #27ae60; color: white; border: none; padding: 10px 20px; border-radius: 4px; font-weight: bold; cursor: pointer; }
        button:hover { background: #219653; }
    </style>
</head>
<body>

    <div class="sidebar">
        <h3>Welcome, <?= htmlspecialchars($_SESSION['username']); ?></h3>
        <p>Role: Peer Reviewer</p>
        <hr style="border: 0; border-top: 1px solid #34495e; margin-bottom: 15px;">
        <a href="reviewer_dashboard.php">Assigned Review Pool</a>
        <a href="logout.php" style="color: #e74c3c; margin-top: 30px;">Sign Out</a>
    </div>

    <div class="main-content">
        <h2>Manuscripts Awaiting Peer Evaluation</h2>
        
        <?php
        // Process review submission right here asynchronously on submission action
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_review'])) {
            $article_id = intval($_POST['article_id']);
            $review_text = $conn->real_escape_string($_POST['review_text']);

            $sql = "INSERT INTO reviews (article_id, reviewer_id, review_text) VALUES ('$article_id', '$reviewer_id', '$review_text')";
            if ($conn->query($sql) === TRUE) {
                // Automatically update parent tracking matrix state to 'Under Review'
                $conn->query("UPDATE articles SET status = 'Under Review' WHERE id = '$article_id'");
                echo "<p style='color: green; background: #e8f8f5; padding: 10px; border-left: 4px solid #2cc16e; margin-bottom: 20px;'>Review updated and logged into editorial review queue!</p>";
            } else {
                echo "<p style='color: red;'>Database Processing Failure: " . $conn->error . "</p>";
            }
        }

        // Pull articles eligible for tracking assessments ('Submitted' or 'Under Review')
        $query = "SELECT * FROM articles WHERE status IN ('Submitted', 'Under Review') ORDER BY id DESC";
        $articles = $conn->query($query);

        if ($articles && $articles->num_rows > 0):
            while($row = $articles->fetch_assoc()):
        ?>
                <div class="article-box">
                    <h4><?= htmlspecialchars($row['title']) ?></h4>
                    <p style="font-size: 14px; color: #555; margin-bottom: 10px;"><strong>Current Workflow Status:</strong> <span style="color:#d35400; font-weight:bold;"><?= $row['status'] ?></span></p>
                    <p style="margin-bottom: 15px; color: #4a5568;"><strong>Abstract Summary:</strong><br><?= htmlspecialchars($row['abstract']) ?></p>
                    <p style="margin-bottom: 15px;"><a href="<?= htmlspecialchars($row['file_path']) ?>" target="_blank" style="color: #2980b9; text-decoration: none; font-weight: 600;">& Download Original Manuscript PDF</a></p>
                    
                    <form action="" method="POST" style="border-top: 1px dashed #e2e8f0; padding-top: 15px;">
                        <input type="hidden" name="article_id" value="<?= $row['id'] ?>">
                        <label style="font-weight: 600; font-size: 14px; color: #2c3e50;">Provide Your Critique / Peer Verification Notes:</label>
                        <textarea name="review_text" required placeholder="Type your full analysis regarding scientific consistency, grammar formatting accuracy, and structural credibility metrics..."></textarea>
                        <button type="submit" name="submit_review">Submit Review Assessment</button>
                    </form>
                </div>
        <?php 
            endwhile; 
        else: 
        ?>
            <p style="color: #718096;">There are currently no active manuscripts in the verification pool requiring review inputs.</p>
        <?php endif; ?>
    </div>

</body>
</html>