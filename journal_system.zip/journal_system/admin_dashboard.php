<?php
include 'db.php';
// Route Guard: Access allowed only for Admins
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Editorial Control Center</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: sans-serif; }
        body { display: flex; background: #f4f6f9; color: #333; }
        .sidebar { width: 260px; background: #1a252f; color: white; height: 100vh; padding: 20px; position: fixed; }
        .sidebar h2 { margin-bottom: 5px; font-size: 20px; }
        .sidebar p { font-size: 13px; color: #cbd5e1; margin-bottom: 20px; }
        .sidebar a { color: #cbd5e1; display: block; padding: 12px; text-decoration: none; border-radius: 4px; margin-bottom: 5px; }
        .sidebar a:hover, .sidebar a.active { color: white; background: #34495e; }
        .main-content { margin-left: 260px; flex: 1; padding: 40px; }
        
        /* Grid Table Styling */
        table { width: 100%; border-collapse: collapse; margin-top: 15px; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #e2e8f0; }
        th { background: #f8fafc; color: #4a5568; font-weight: 600; }
        select { padding: 6px 10px; border: 1px solid #cbd5e1; border-radius: 4px; background: #fff; }
        .btn-save { background: #3182ce; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-weight: bold; }
        .btn-save:hover { background: #2b6cb0; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Journal Admin</h2>
        <p>User: <?= htmlspecialchars($_SESSION['username']); ?></p><hr style="border:0; border-top:1px solid #34495e; margin-bottom:15px;">
        
        <?php $view = $_GET['view'] ?? 'reviews'; ?>
        <a href="?view=reviews" class="<?= $view == 'reviews' ? 'active' : '' ?>">Verify Peer Reviews</a>
        <a href="?view=publish" class="<?= $view == 'publish' ? 'active' : '' ?>">Journal Management (Publish)</a>
        <a href="?view=roles" class="<?= $view == 'roles' ? 'active' : '' ?>">Manage Users & Roles ⚙</a>
        <a href="logout.php" style="color: #ff6b6b; margin-top: 30px;">Logout</a>
    </div>

    <div class="main-content">
        <?php
        if ($view == 'publish') {
            include 'admin_publish.php';
        } elseif ($view == 'roles') {
            // INJECTED ROLE PROMOTION UTILITY PANEL
            include 'admin_roles.php'; 
        } else {
            echo '<h2>Pending Reviews Evaluation</h2><br>';
            $res = $conn->query("SELECT r.id, r.review_text, a.title FROM reviews r JOIN articles a ON r.article_id = a.id WHERE r.admin_review_status = 'Pending'");
            if ($res->num_rows == 0) echo "<p style='color:#718096;'>No reviews are currently awaiting validation action.</p>";
            while($item = $res->fetch_assoc()) {
                echo "<div style='border:1px solid #e2e8f0; background:#fff; padding:20px; margin-bottom:15px; border-radius:6px;'>
                        <h4>Article: " . htmlspecialchars($item['title']) . "</h4>
                        <p style='margin:10px 0; color:#4a5568;'>Reviewer Critique: " . htmlspecialchars($item['review_text']) . "</p>
                        <a href='admin_review_action.php?review_id={$item['id']}&action=Accept' style='color:#2f855a; font-weight:600; text-decoration:none;'>[✓ Accept Review & Article]</a> &nbsp;&nbsp;|&nbsp;&nbsp; 
                        <a href='admin_review_action.php?review_id={$item['id']}&action=Reject' style='color:#c53030; font-weight:600; text-decoration:none;'>[✕ Reject Review]</a>
                      </div>";
            }
        }
        ?>
    </div>
</body>
</html>