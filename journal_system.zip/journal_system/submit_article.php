<?php
include 'db.php';

// Mock session login for testing (e.g., Author ID 1)
$_SESSION['user_id'] = 1; 
$_SESSION['role'] = 'Author';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_SESSION['role'] == 'Author') {
    $title = $conn->real_escape_string($_POST['title']);
    $abstract = $conn->real_escape_string($_POST['abstract']);
    
    // File Upload Handling
    $target_dir = "uploads/manuscripts/";
    // Fix: Automatically build folders if they are missing at runtime
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    $file_name = time() . "_" . basename($_FILES["article_file"]["name"]);
    $target_file = $target_dir . $file_name;

    if (move_uploaded_file($_FILES["article_file"]["tmp_name"], $target_file)) {
        $author_id = $_SESSION['user_id'];
        $sql = "INSERT INTO articles (author_id, title, abstract, file_path, status) 
                VALUES ('$author_id', '$title', '$abstract', '$target_file', 'Submitted')";
        
        if ($conn->query($sql) === TRUE) {
            echo "Article submitted successfully!";
        } else {
            echo "Database Error: " . $conn->error;
        }
    } else {
        echo "Failed to upload manuscript file.";
    }
}
?>

<form action="" method="POST" enctype="multipart/form-data">
    <h2>Submit Article</h2>
    <input type="text" name="title" placeholder="Article Title" required><br><br>
    <textarea name="abstract" placeholder="Abstract/Summary" required></textarea><br><br>
    <input type="file" name="article_file" accept=".pdf" required><br><br>
    <button type="submit">Submit Article</button>
</form>