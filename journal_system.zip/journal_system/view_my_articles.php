<?php
include 'db.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Author') { exit("Unauthorized Access"); }

$author_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM articles WHERE author_id = $author_id ORDER BY id DESC");
?>
<style>
    .status-badge { padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 12px; }
    .Submitted { background: #e2e8f0; color: #4a5568; }
    .Under-Review { background: #feebc8; color: #c05621; }
    .Accepted { background: #c6f6d5; color: #22543d; }
    .Rejected { background: #fed7d7; color: #9b2c2c; }
    .Published { background: #ebf8ff; color: #2b6cb0; }
</style>

<h3>My Submitted Articles</h3><br>
<table border="1" cellpadding="10" cellspacing="0" style="width:100%; border-collapse:collapse; background:#fff;">
    <thead style="background:#f7fafc;">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Submission Date</th>
            <th>Current Status</th>
            <th>Manuscript File</th>
        </tr>
    </thead>
    <tbody>
        <?php while($row = $result->fetch_assoc()): 
            $status_class = str_replace(' ', '-', $row['status']);
        ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><strong><?= htmlspecialchars($row['title']) ?></strong></td>
            <td><?= date('M d, Y', strtotime($row['created_at'])) ?></td>
            <td><span class="status-badge <?= $status_class ?>"><?= $row['status'] ?></span></td>
            <td><a href="<?= htmlspecialchars($row['file_path']) ?>" target="_blank">View PDF</a></td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>